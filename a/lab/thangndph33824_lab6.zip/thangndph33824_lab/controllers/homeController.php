<?php
class HomeController
{
    public function trangChu()
    {
        require_once "./views/home.php";
    }


}
