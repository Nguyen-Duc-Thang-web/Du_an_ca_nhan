<?php
define('BASE_DIR', 'http://php1.test/thangndph33824_lab/');

define('IMG_PATH', 'http://php1.test/thangndph33824_lab/uploads/');

define('DB_HOST', 'localhost');
define('DB_NAME', 'l1');
define('DB_USER', 'root');
define('DB_PASS', '');