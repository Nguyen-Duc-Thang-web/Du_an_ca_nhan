<?php
define('BASE_DIR', 'http://php1.test/PHP1_ASS1/');
define('IMG_PATH', 'http://php1.test/PHP1_ASS1/uploads/');

define('DB_HOST', 'localhost');
define('DB_NAME', 'lan-3');
define('DB_USER', 'root');
define('DB_PASS', '');